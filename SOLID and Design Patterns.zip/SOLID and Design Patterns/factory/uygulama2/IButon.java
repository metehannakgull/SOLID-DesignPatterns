package cc.ders12.factory.uygulama2;

interface IButon {
    public abstract void onClick();
    public abstract void onDblClick();
}
