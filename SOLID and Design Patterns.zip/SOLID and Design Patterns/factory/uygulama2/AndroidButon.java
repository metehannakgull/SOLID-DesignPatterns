package cc.ders12.factory.uygulama2;

class AndroidButon implements IButon {

    String etiket;

    AndroidButon(){
        System.out.println("Android butonu oluştu");

    }


    @Override
    public void onClick() {

    }

    @Override
    public void onDblClick() {

    }

}
