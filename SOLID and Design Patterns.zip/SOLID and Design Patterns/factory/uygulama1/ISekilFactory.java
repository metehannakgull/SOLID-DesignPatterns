package cc.ders12.factory.uygulama1;

public interface ISekilFactory {
    public ISekil factoryMethod();
}
