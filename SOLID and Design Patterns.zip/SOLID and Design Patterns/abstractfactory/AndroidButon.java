package cc.ders12.abstractfactory;

class AndroidButon implements IButon {
    AndroidButon(String arg){
        System.out.println("Android butonu oluştu");
    } // Implement the code here
    public void by1() { };
    public void by2() { };
}
