package cc.ders12.abstractfactory;

interface IButon {
    public abstract void by1();
    public abstract void by2();
}
