package cc.ders10.ocp.uygulama2;

public interface IFaturaServisi {
    String faturaOlustur(Fatura fatura);
}
