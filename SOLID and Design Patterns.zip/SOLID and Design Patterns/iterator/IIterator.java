package cc.ders12.iterator;

public interface IIterator {
    public boolean hasNext();
    public Object next();
}
