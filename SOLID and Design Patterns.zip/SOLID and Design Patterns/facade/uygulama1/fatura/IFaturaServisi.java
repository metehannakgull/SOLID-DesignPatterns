package cc.ders12.facade.uygulama1.fatura;

public interface IFaturaServisi {
    String faturaOlustur(Fatura fatura);
}
