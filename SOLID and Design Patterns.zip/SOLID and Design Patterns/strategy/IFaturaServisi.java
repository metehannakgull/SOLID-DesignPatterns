package cc.ders12.strategy;

public interface IFaturaServisi {
    String faturaOlustur(Fatura fatura);
}
